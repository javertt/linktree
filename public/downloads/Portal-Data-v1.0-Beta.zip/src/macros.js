(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  root.PortalMacros = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  function safeUrl(url) {
    if (!url) return '';
    try {
      const parsed = new URL(url);
      if (parsed.protocol !== 'https:' || !/\.gif$/i.test(parsed.pathname) || /[\s(){}\[\]]/.test(url)) return '';
      return parsed.href;
    } catch { return ''; }
  }
  function safeLabel(label) { return String(label).replace(/[\r\n{}\[\]|=<>]/g, ' ').trim().slice(0, 80); }
  function macroName(label) { return 'PD-' + safeLabel(label).normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-zA-Z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 35); }
  function create({ name, gifUrl = '', dice = '', attackBonus = null }) {
    const url = safeUrl(gifUrl);
    if (gifUrl && !url) throw new Error('Informe uma URL HTTPS direta terminada em .gif.');
    const label = safeLabel(name);
    if (!label) throw new Error('Item ou magia sem nome.');
    const roll = dice.trim();
    if (roll && !/^\d{1,2}d\d{1,3}(?:[+-]\d{1,3})?$/i.test(roll)) throw new Error('Dados: use formato como 1d6+2.');
    const hasBonus = attackBonus !== null && attackBonus !== undefined && String(attackBonus).trim() !== '';
    const bonus = hasBonus ? Number(attackBonus) : null;
    if (hasBonus && (!Number.isInteger(bonus) || Math.abs(bonus) > 999)) throw new Error('Bônus de ataque: informe um número inteiro entre -999 e 999.');
    if (!url && !roll && !hasBonus) throw new Error('Informe os dados do ataque ou um GIF.');
    const lines = hasBonus
      ? [`&{template:default} {{name=${label}}} {{Ataque=[[1d20${bonus >= 0 ? '+' : ''}${bonus}]]}}${roll ? ` {{Dano=[[${roll}]]}}` : ''}${url ? ` {{Efeito=[${label}](${url})}}` : ''}`]
      : [`/em usa ${label}`, ...(url ? [`[${label}](${url})`] : []), ...(roll ? [`/roll ${roll}`] : [])];
    return { name: macroName(label), body: lines.join('\n') };
  }
  return { create, safeUrl, macroName };
});
