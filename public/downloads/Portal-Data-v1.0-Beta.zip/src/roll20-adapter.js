(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  root.PortalRoll20 = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const T20 = {
    id: 't20', label: 'Tormenta20',
    fields: { name: 'attr_character_name', hp: 'attr_vida', hpMax: 'attr_vidatotal', mp: 'attr_mana', mpMax: 'attr_manatotal' },
    abilities: { strength: 'attr_for', dexterity: 'attr_des', constitution: 'attr_con', intelligence: 'attr_int', wisdom: 'attr_sab', charisma: 'attr_car' },
    repeaters: {
      inventory: { group: 'repeating_equipment', name: 'attr_equipname', count: 'attr_equipquantity' },
      attacks: { group: 'repeating_attacks', name: 'attr_nomeataque', description: 'attr_ataquedescricao' },
      spells: { groupPattern: 'repeating_spells{level}', name: 'attr_namespell', description: 'attr_spelldescription', minLevel: 1, maxLevel: 5 }
    }
  };
  // Mapeado a partir do diagnóstico da ficha oficial Tormenta20 Jogo do Ano.
  // A aba Ameaça é uma visualização gerada por Sheet Workers a partir da ficha Jogador.
  const T20_THREAT = {
    id: 't20-threat', label: 'Tormenta20 Ficha Ameaça',
    fields: { name: 'attr_character_name', hp: 'attr_vida', hpMax: 'attr_vidatotal', mp: 'attr_mana', mpMax: 'attr_manatotal' },
    abilities: { ...T20.abilities },
    repeaters: {
      inventory: T20.repeaters.inventory,
      attacks: T20.repeaters.attacks,
      features: { group: 'repeating_abilities', name: 'attr_nameability', description: 'attr_abilitydescription' },
      spells: T20.repeaters.spells
    }
  };
  const DND = {
    id: 'dnd5e2014', label: 'D&D 5e 2014 Legacy',
    fields: { name: 'attr_character_name', hp: 'attr_hp', hpMax: 'attr_hp_max' },
    abilities: { strength: 'attr_strength_base', dexterity: 'attr_dexterity_base', constitution: 'attr_constitution_base', intelligence: 'attr_intelligence_base', wisdom: 'attr_wisdom_base', charisma: 'attr_charisma_base' },
    repeaters: {
      inventory: { group: 'repeating_inventory', name: 'attr_itemname', count: 'attr_itemcount' },
      attacks: { group: 'repeating_attack', name: 'attr_atkname', description: 'attr_atk_desc' },
      spells: { groupPattern: 'repeating_spell-{level}', name: 'attr_spellname', description: 'attr_spelldescription', minLevel: 0, maxLevel: 9, zeroName: 'cantrip' }
    }
  };
  const normalize = (value) => String(value).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();
  const safeAttr = (value) => typeof value === 'string' && /^attr_[a-zA-Z0-9_-]+$/.test(value);
  const safeGroup = (value) => typeof value === 'string' && /^repeating_[a-zA-Z0-9_-]+$/.test(value);
  const field = (scope, name) => safeAttr(name) ? scope.querySelector(`[name="${name}"]:is(input,textarea,select):not([type="hidden"]):not([disabled])`) : null;
  const pause = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  const visible = (element) => !!element && !!(element.getClientRects().length || element.offsetParent !== null);

  function detect(scope) {
    const threatTab = tabControl(scope, 'Ficha Ameaça');
    const playerTab = tabControl(scope, 'Ficha Jogador');
    if (threatTab?.classList.contains('sheet-switch-selected') && groupContainer(scope, 'repeating_menacemelee')) return T20_THREAT;
    if (playerTab?.classList.contains('sheet-switch-selected') && field(scope, 'attr_for') && field(scope, 'attr_vida')) return T20;
    if (visible(field(scope, 'attr_menace_name')) && groupContainer(scope, 'repeating_menacemelee')) return T20_THREAT;
    if (field(scope, 'attr_for') && field(scope, 'attr_vida')) return { ...T20, variant: scope.querySelector('[data-i18n="global_charactersheet"]') ? 'Jogo do Ano' : 'clássica' };
    if (field(scope, 'attr_strength_base') && field(scope, 'attr_hp')) return DND;
    return null;
  }
  function scopeOf(doc) {
    const sheets = [...doc.querySelectorAll('.charsheet')].filter((el) => el.getClientRects().length || el.offsetParent !== null);
    if (sheets.length === 1) return sheets[0];
    if (sheets.length > 1) throw new Error('Há várias fichas abertas neste quadro. Deixe apenas uma aberta.');
    return null;
  }
  function probe(doc, detailed = true) {
    const sheets = [...doc.querySelectorAll('.charsheet')];
    const visibleSheetCount = sheets.filter((el) => el.getClientRects().length || el.offsetParent !== null).length;
    let scope;
    try { scope = scopeOf(doc); } catch (error) { return { supported: false, error: error.message, sheetCount: sheets.length, visibleSheetCount }; }
    if (!scope) return { supported: false, reason: sheets.length ? 'Há uma ficha no quadro, mas ela não está visível.' : 'Nenhuma .charsheet encontrada neste quadro.', sheetCount: sheets.length, visibleSheetCount };
    const profile = detect(scope);
    const name = (profile?.id === 't20-threat' ? field(scope, 'attr_menace_name')?.value : null) || field(scope, 'attr_character_name')?.value || field(scope, 'attr_name')?.value || 'Ficha sem nome';
    if (!detailed && profile) return { supported: true, profile: profile.id, variant: profile.variant || '', name,
      fields: [], groups: [], groupFields: {}, sheetCount: sheets.length, visibleSheetCount };
    const names = [...scope.querySelectorAll('[name^="attr_"]')].map((el) => el.name).filter((name) => typeof name === 'string');
    const containers = [...scope.querySelectorAll('.repcontainer[data-groupname^="repeating_"]')];
    const groups = containers.map((el) => el.dataset.groupname);
    const templates = [...scope.querySelectorAll('fieldset'), ...doc.querySelectorAll('fieldset')];
    const groupFields = Object.fromEntries(containers.map((container) => {
      const group = container.dataset.groupname;
      const template = templates.find((el) => el.classList.contains(group));
      const inputs = [...(template?.querySelectorAll('[name^="attr_"]') || []), ...container.querySelectorAll('[name^="attr_"]')];
      return [group, [...new Set(inputs.map((el) => el.name).filter(Boolean))]];
    }));
    const basic = { supported: true, profile: profile?.id || 'generic', variant: profile?.variant || '', name, fields: [...new Set(names)].slice(0, 1000), groups: [...new Set(groups)], groupFields, sheetCount: sheets.length, visibleSheetCount };
    if (!detailed) return basic;
    const groupControls = Object.fromEntries(containers.map((container) => {
      const group = container.dataset.groupname;
      const template = templates.find((el) => el.classList.contains(group));
      const inputs = [...(template?.querySelectorAll('[name^="attr_"]') || []), ...container.querySelectorAll('[name^="attr_"]')];
      return [group, inputs.slice(0, 80).map((el) => ({ name: el.name, tag: el.tagName.toLowerCase(),
        placeholder: (el.getAttribute('placeholder') || '').slice(0, 80),
        title: (el.getAttribute('title') || '').slice(0, 80),
        label: (el.getAttribute('aria-label') || '').slice(0, 80) }))];
    }));
    const summary = (el) => el ? `${el.tagName.toLowerCase()}.${[...el.classList].slice(0, 5).join('.')}${el.dataset?.groupname ? `[${el.dataset.groupname}]` : ''}` : '';
    const groupLayout = Object.fromEntries(containers.map((container) => {
      const group = container.dataset.groupname;
      const ancestors = [];
      for (let node = container.parentElement, i = 0; node && node !== scope && i < 4; node = node.parentElement, i++) {
        ancestors.push({ element: summary(node), groups: node.querySelectorAll('.repcontainer[data-groupname^="repeating_"]').length,
          addButtons: node.querySelectorAll('.repcontrol_add').length });
      }
      return [group, { rows: rows(container).length, container: summary(container), parent: summary(container.parentElement),
        previous: summary(container.previousElementSibling), next: summary(container.nextElementSibling),
        labelledControls: scope.querySelectorAll(`.repcontrol[data-groupname="${group}"] .repcontrol_add`).length,
        selectedControl: summary(addControl(scope, group, container)), ancestors }];
    }));
    const controls = [...scope.querySelectorAll('[name^="attr_"]:is(input,textarea,select)')]
      .filter((el) => el.getClientRects().length || el.offsetParent !== null)
      .slice(0, 250).map((el) => ({ name: el.name, tag: el.tagName.toLowerCase(),
        placeholder: (el.getAttribute('placeholder') || '').slice(0, 80),
        title: (el.getAttribute('title') || '').slice(0, 80),
        label: (el.getAttribute('aria-label') || '').slice(0, 80) }));
    const coreNames = /^(?:attr_(?:for|des|con|int|sab|car|vida|vidatotal|mana|manatotal|defesafake|defesaoutros|defesatotal|iniciativa(?:total|outros)|percepcao(?:total|outros)|fortitude(?:total|outros)|reflexos(?:total|outros)|vontade(?:total|outros)|furtividade(?:total|outros)|sobrevivencia(?:total|outros)))$/;
    const coreControls = [...scope.querySelectorAll('[name^="attr_"]:is(input,textarea,select)')]
      .filter((el) => coreNames.test(el.name)).map((el) => ({ name: el.name,
        tag: el.tagName.toLowerCase(), type: el.type || '', readOnly: !!el.readOnly,
        disabled: !!el.disabled, visible: !!(el.getClientRects().length || el.offsetParent !== null) }));
    const tabs = ['Ficha Jogador', 'Ficha Ameaça'].map((title) => {
      const element = tabControl(scope, title);
      return { title, found: !!element, element: summary(element), parent: summary(element?.parentElement) };
    });
    return { ...basic, groupControls, groupLayout, tabs, controls, coreControls };
  }
  function validateProfile(profile) {
    if (!profile || typeof profile !== 'object') throw new Error('Perfil JSON inválido.');
    if (!Object.keys(profile.fields || {}).length && !Object.keys(profile.abilities || {}).length && !Object.keys(profile.repeaters || {}).length && !Object.keys(profile.extraFields || {}).length) throw new Error('Perfil sem campos mapeados.');
    for (const value of Object.values(profile.fields || {})) if (!safeAttr(value)) throw new Error(`Atributo inválido: ${value}`);
    for (const value of Object.values(profile.abilities || {})) if (!safeAttr(value)) throw new Error(`Atributo inválido: ${value}`);
    for (const section of Object.values(profile.repeaters || {})) {
      if (section.group && !safeGroup(section.group)) throw new Error(`Grupo inválido: ${section.group}`);
      if (section.groupPattern && !safeGroup(section.groupPattern.replace('{level}', '1'))) throw new Error('groupPattern inválido.');
      for (const key of ['name', 'count', 'description']) if (section[key] && !safeAttr(section[key])) throw new Error(`Campo inválido: ${section[key]}`);
    }
    return profile;
  }
  function setValue(element, value) {
    if (!element || value === null || value === undefined) return false;
    const next = String(value);
    if (element.value === next) return false;
    const proto = element instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : element instanceof HTMLSelectElement ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
    element.focus();
    setter.call(element, next);
    element.dispatchEvent(new Event('input', { bubbles: true }));
    element.dispatchEvent(new Event('change', { bubbles: true }));
    element.blur();
    // Campos em abas ocultas não recebem foco real; o Roll20 também escuta
    // focusout para consolidar alterações em algumas fichas.
    element.dispatchEvent(new Event('focusout', { bubbles: true }));
    return true;
  }
  function setChecked(element, checked) {
    if (!element || element.type !== 'checkbox' || element.checked === checked) return false;
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'checked')?.set;
    element.focus();
    setter.call(element, checked);
    element.dispatchEvent(new Event('input', { bubbles: true }));
    element.dispatchEvent(new Event('change', { bubbles: true }));
    element.blur();
    return true;
  }
  function groupContainer(scope, group) {
    if (!safeGroup(group)) return null;
    return scope.querySelector(`.repcontainer[data-groupname="${group}"]`) || scope.querySelector(`fieldset.${group}`);
  }
  function rows(container) { return [...(container?.querySelectorAll('.repitem') || [])]; }
  function addControl(scope, group, container) {
    // O Roll20 atribui data-groupname também ao controle. A ficha pode mover
    // visualmente esse controle, então a posição como irmão não é confiável.
    const labelled = [...scope.querySelectorAll(`.repcontrol[data-groupname="${group}"] .repcontrol_add`)];
    if (labelled.length === 1) return labelled[0];
    const visibleControls = labelled.filter(visible);
    if (visibleControls.length === 1) return visibleControls[0];
    if (labelled.length > 1) return null;
    for (let wrapper = container.parentElement; wrapper && wrapper !== scope; wrapper = wrapper.parentElement) {
      const sections = wrapper.querySelectorAll('.repcontainer[data-groupname^="repeating_"]');
      const buttons = wrapper.querySelectorAll('.repcontrol_add');
      if (sections.length === 1 && buttons.length === 1) return buttons[0];
      if (sections.length > 1) break;
    }
    // Em versões sem data-groupname, a ordem da primeira seção indica se
    // o controle fica antes ou depois de seu container. Não atravesse outra seção.
    const siblings = [...container.parentElement.children].filter((element) =>
      element.matches('.repcontainer,[data-groupname^="repeating_"],.repcontrol'));
    const controlBefore = siblings[0]?.matches('.repcontrol');
    const directions = controlBefore ? ['previousElementSibling', 'nextElementSibling'] : ['nextElementSibling', 'previousElementSibling'];
    for (const direction of directions) {
      let sibling = container[direction];
      while (sibling && !sibling.matches('.repcontainer,[data-groupname^="repeating_"]')) {
        if ([...sibling.classList].some((name) => name.startsWith('repeating_') && name !== group)) break;
        const button = sibling.matches('.repcontrol_add') ? sibling : sibling.querySelector('.repcontrol_add');
        if (button) return button;
        sibling = sibling[direction];
      }
    }
    return null;
  }
  function tabControl(scope, title) {
    const sameText = (element) => normalize(element.textContent || '') === normalize(title);
    const controls = [...scope.querySelectorAll('label,button,a,[role="tab"]')].filter((element) => visible(element) && sameText(element));
    if (controls.length === 1) return controls[0];
    const leaves = [...scope.querySelectorAll('span,div')].filter((element) =>
      visible(element) && sameText(element) && ![...element.children].some(sameText));
    if (leaves.length !== 1) return null;
    return leaves[0].closest('label,button,a,[role="tab"]') || leaves[0];
  }
  async function showTab(scope, title, expectedAttr) {
    const control = tabControl(scope, title);
    if (control?.classList.contains('sheet-switch-selected')) return true;
    const selectedTab = [...scope.querySelectorAll('.sheet-switch-selected')].some((element) =>
      normalize(element.textContent || '') === normalize('Ficha Jogador') || normalize(element.textContent || '') === normalize('Ficha Ameaça'));
    if (!selectedTab && visible(field(scope, expectedAttr))) return true;
    if (!control) return false;
    control.click();
    for (let i = 0; i < 30; i++) {
      await pause(100);
      if (tabControl(scope, title)?.classList.contains('sheet-switch-selected')) return true;
      if (!selectedTab && visible(field(scope, expectedAttr))) return true;
    }
    return false;
  }
  async function addRow(scope, group, requiredAttr, report) {
    const container = groupContainer(scope, group);
    if (!container) return null;
    const before = new Set(rows(container).map((row) => row.dataset.reprowid || row));
    const control = addControl(scope, group, container);
    if (!control || control.disabled) {
      report?.warnings.push(`${group}: botão Adicionar não encontrado ou desabilitado.`);
      return null;
    }
    control.click();
    let appeared = false;
    for (let i = 0; i < 60; i++) {
      await pause(100);
      const fresh = rows(groupContainer(scope, group)).find((row) => !before.has(row.dataset.reprowid || row));
      if (!fresh) continue;
      appeared = true;
      if (!requiredAttr || field(fresh, requiredAttr)) return fresh;
    }
    report?.warnings.push(appeared ? `${group}: nova linha apareceu sem ${requiredAttr}.` : `${group}: botão Adicionar acionado, mas nenhuma linha apareceu após 6 segundos.`);
    return null;
  }
  function existingRow(scope, group, nameAttr, name) {
    const container = groupContainer(scope, group);
    if (!container) return null;
    return rows(container).find((row) => normalize(field(row, nameAttr)?.value || '') === normalize(name));
  }
  function blankRow(scope, group, nameAttr) {
    const container = groupContainer(scope, group);
    if (!container) return null;
    return rows(container).find((row) => {
      const nameField = field(row, nameAttr);
      if (!nameField || nameField.value.trim()) return false;
      const values = [...row.querySelectorAll('[name^="attr_"]:is(input,textarea):not([type="hidden"]):not([type="checkbox"]):not([disabled])')];
      return values.every((element) => element === nameField || !element.value.trim() || element.value.trim() === '0');
    });
  }
  function gifFor(gifs, name) { return Object.entries(gifs || {}).find(([key]) => normalize(key) === normalize(name))?.[1] || ''; }
  function imageMarkdown(name, url) { return `[${String(name).replace(/[\[\]()\r\n]/g, ' ')}](${url})`; }
  function groupFor(section, item) {
    if (section.group) return section.group;
    if (item.level === null || item.level === undefined) return '';
    const level = item.level === 0 && section.zeroName ? section.zeroName : item.level;
    if (typeof level === 'number' && ((section.minLevel !== undefined && level < section.minLevel) || (section.maxLevel !== undefined && level > section.maxLevel))) return '';
    return section.groupPattern?.replace('{level}', String(level)) || '';
  }
  async function addEntries(scope, section, entries, gifs, report) {
    if (!section) { report.skipped += entries.length; return; }
    let failed = false;
    for (const entry of entries) {
      if (failed) { report.skipped++; continue; }
      const group = groupFor(section, entry);
      if (!group) { report.warnings.push(`${entry.name}: nível/círculo ausente ou fora do perfil.`); report.skipped++; continue; }
      if (!groupContainer(scope, group)) { report.warnings.push(`Seção ${group} não encontrada/visível; ${entry.name} ignorado.`); report.skipped++; continue; }
      let row = existingRow(scope, group, section.name, entry.name);
      if (!row) {
        row = blankRow(scope, group, section.name);
        const reused = !!row;
        if (!row) row = await addRow(scope, group, section.name, report);
        if (!row) { failed = true; report.skipped++; continue; }
        const nameField = field(row, section.name);
        if (!nameField) { report.warnings.push(`${group}: campo ${section.name} ausente na nova linha.`); report.skipped++; continue; }
        setValue(nameField, entry.name);
        if (reused) report.reused++;
        else report.added++;
      } else report.existing++;
      if (section.count && entry.count) {
        const countField = field(row, section.count);
        if (countField) setValue(countField, entry.count);
        else report.warnings.push(`${entry.name}: campo ${section.count} ausente.`);
      }
      const url = gifFor(gifs, entry.name);
      if (url && section.description) {
        const target = field(row, section.description);
        if (target && !target.value.includes(url)) setValue(target, [target.value, imageMarkdown(entry.name, url)].filter(Boolean).join('\n'));
        else if (!target) report.warnings.push(`${entry.name}: campo de descrição indisponível para GIF.`);
      }
      await pause(80);
    }
  }
  function write(scope, attr, value, report) {
    if (value === null || value === undefined) return;
    const target = field(scope, attr);
    if (!target) report.warnings.push(`${attr} não encontrado ou editável.`);
    else if (setValue(target, value)) report.changed++;
  }
  const statNumber = (element) => {
    const value = element?.value?.trim();
    return value && /^[+-]?\d+(?:[.,]\d+)?$/.test(value) ? Number(value.replace(',', '.')) : null;
  };
  async function adjustCalculated(scope, label, desired, otherAttr, totalAttrs, report) {
    if (!Number.isFinite(desired)) return null;
    const other = field(scope, otherAttr);
    const total = totalAttrs.map((name) => scope.querySelector(`[name="${name}"]`)).find((el) => statNumber(el) !== null);
    if (!other || !total) {
      report.warnings.push(`${label}: total calculado indisponível; ajuste manual necessário.`);
      report.skipped++;
      return null;
    }
    const current = statNumber(total);
    const modifier = statNumber(other) ?? 0;
    if (current !== desired && setValue(other, modifier + desired - current)) report.changed++;
    await pause(140);
    return { label, desired, initial: current, otherAttr, totalAttr: total.name };
  }
  async function verifyCalculated(scope, pending, report) {
    if (!pending.length) return;
    for (let i = 0; i < 8; i++) {
      if (pending.every((item) => statNumber(scope.querySelector(`[name="${item.totalAttr}"]`)) === item.desired)) return;
      await pause(200);
    }
    // Uma atualização tardia dos atributos pode mudar a base do cálculo.
    // Corrigimos uma vez somente se o total realmente mudou após a escrita.
    for (const item of pending) {
      const observed = statNumber(scope.querySelector(`[name="${item.totalAttr}"]`));
      const other = field(scope, item.otherAttr);
      if (observed === item.desired || observed === null || observed === item.initial || !other) continue;
      if (setValue(other, (statNumber(other) ?? 0) + item.desired - observed)) report.changed++;
    }
    await pause(600);
    for (const item of pending) {
      const actual = statNumber(scope.querySelector(`[name="${item.totalAttr}"]`));
      if (actual !== item.desired) report.warnings.push(`${item.label}: esperado ${item.desired}, total lido ${actual === null ? 'indisponível' : actual}; confira na ficha.`);
    }
  }
  async function addSourceEntry(scope, section, name, values, gifs, report) {
    const group = section.group;
    if (!groupContainer(scope, group)) { report.warnings.push(`Seção ${group} não encontrada.`); report.skipped++; return; }
    let row = existingRow(scope, group, section.name, name);
    if (!row) {
      row = blankRow(scope, group, section.name);
      const reused = !!row;
      if (!row) row = await addRow(scope, group, section.name, report);
      if (!row) { report.skipped++; return; }
      if (!field(row, section.name)) { report.warnings.push(`${group}: linha criada sem ${section.name}.`); report.skipped++; return; }
      write(row, section.name, name, report);
      if (reused) report.reused++;
      else report.added++;
    } else report.existing++;
    const url = gifFor(gifs, name.replace(/ x\d+$/, ''));
    const prepared = { ...values };
    if (url && section.description && prepared[section.description] !== undefined) {
      prepared[section.description] = [prepared[section.description], imageMarkdown(name, url)].filter(Boolean).join('\n');
    }
    for (const [attr, value] of Object.entries(prepared)) {
      if (attr === 'attr_ataquepericia') {
        const control = field(row, attr);
        const option = [...(control?.options || [])].find((item) => normalize(item.textContent) === normalize(value));
        if (option) write(row, attr, option.value, report);
        else report.warnings.push(`${name}: perícia ${value} não encontrada no ataque.`);
      } else write(row, attr, value, report);
    }
    if (url && section.description && prepared[section.description] === undefined) {
      const target = field(row, section.description);
      if (target && !target.value.includes(url)) write(row, section.description, [target.value, imageMarkdown(name, url)].filter(Boolean).join('\n'), report);
      else if (!target) report.warnings.push(`${name}: campo de descrição indisponível para GIF.`);
    }
    await pause(80);
  }
  function attackBase(scope, mode, report) {
    const skill = mode === 'ranged' ? 'pontaria' : 'luta';
    const skillTotal = statNumber(scope.querySelector(`[name="attr_${skill}total"]`));
    if (skillTotal === null) report.warnings.push(`${skill}: total não disponível; confira o bônus do ataque na ficha.`);
    const extra = ['attr_condicaomodataque', mode === 'ranged' ? 'attr_condicaomodataquedis' : 'attr_condicaomodataquecc', 'attr_ataquetemp']
      .reduce((sum, attr) => sum + (statNumber(scope.querySelector(`[name="${attr}"]`)) ?? 0), 0);
    return (skillTotal ?? 0) + extra;
  }
  async function addPlayerAttack(scope, attack, gifs, report) {
    const name = `${attack.name}${attack.count > 1 ? ` x${attack.count}` : ''}`;
    const damage = String(attack.damage || '').replace(/\s+/g, '');
    const parts = damage.match(/^(\d+d\d+)([+-]\d+)?$/i);
    if (!parts) report.warnings.push(`${name}: dano não reconhecido; confira a rolagem na ficha.`);
    const values = {
      attr_ataquepericia: attack.mode === 'ranged' ? 'Pontaria' : 'Luta',
      attr_bonusataque: Number.isFinite(attack.bonus) ? attack.bonus - attackBase(scope, attack.mode, report) : 0,
      attr_danoataque: parts ? parts[1] : damage || '0',
      attr_danoextraataque: parts?.[2] ? Number(parts[2]) : 0,
      attr_dadoextraataque: 0,
      attr_modatributodano: 0,
      attr_margemcriticoataque: attack.critical || 20,
      attr_multiplicadorcriticoataque: 2
    };
    await addSourceEntry(scope, T20_THREAT.repeaters.attacks, name, values, gifs, report);
  }
  async function waitForProjection(scope, group, nameAttr, name) {
    const container = groupContainer(scope, group);
    if (!container) return false;
    for (let i = 0; i < 40; i++) {
      if (rows(container).some((row) => normalize(row.querySelector(`[name="${nameAttr}"]`)?.value || '') === normalize(name))) return true;
      await pause(100);
    }
    return false;
  }
  async function applyThreat(scope, data, gifs, report) {
    const threatExpected = [];
    const playerExpected = [];
    const pacedWrite = async (attr, value) => {
      if (value === null || value === undefined) return;
      write(scope, attr, value, report);
      await pause(140);
    };
    const threatWrite = async (attr, value) => {
      if (value === null || value === undefined) return;
      threatExpected.push([attr, String(value)]);
      await pacedWrite(attr, value);
    };
    const playerWrite = async (attr, value) => {
      if (value === null || value === undefined) return;
      playerExpected.push([attr, String(value)]);
      await pacedWrite(attr, value);
    };
    const playerReady = await showTab(scope, 'Ficha Jogador', 'attr_for');
    if (!playerReady) {
      report.warnings.push('Não foi possível abrir Ficha Jogador; nome, atributos, ataques, habilidades e equipamentos não foram importados.');
      report.skipped += 1 + (data.inventory || []).length + (data.attacks || []).length + (data.features || []).length + (data.spells || []).length;
    } else {
      try {
        await playerWrite('attr_character_name', data.name);
        await playerWrite('attr_vidatotal', data.hpMax);
        await playerWrite('attr_vida', data.hp);
        await playerWrite('attr_manatotal', data.mpMax);
        await playerWrite('attr_mana', data.mp);
        for (const [key, attr] of Object.entries(T20_THREAT.abilities)) await playerWrite(attr, data.abilities?.[key]);
        const listedSkills = [];
        for (const skill of data.skills || []) {
          const stem = normalize(skill.name).replace(/\s+/g, '');
          if (!/^[a-z]+$/.test(stem) || !scope.querySelector(`[name="attr_${stem}total"]`) || !field(scope, `attr_${stem}outros`)) {
            report.warnings.push(`Perícia ${skill.name}: mapeamento ainda não confirmado.`); report.skipped++; continue;
          }
          const trained = field(scope, `attr_${stem}_treinada`);
          if (trained?.type === 'checkbox' && setChecked(trained, true)) report.changed++;
          await pause(140);
          listedSkills.push({ label: skill.name, desired: skill.bonus, stem });
        }
        // Os totais dependem dos atributos da aba Jogador e de Sheet Workers.
        await pause(500);
        for (const [attr, desired] of playerExpected) {
          if (field(scope, attr)?.value !== desired) {
            write(scope, attr, desired, report);
            await pause(180);
          }
        }
        await pause(500);
        const totals = [
          ['Iniciativa', data.initiative, 'iniciativa', ['attr_iniciativatotal']],
          ['Percepção', data.perception, 'percepcao', ['attr_percepcaototal']],
          ['Defesa', data.defense, 'defesa', ['attr_defesafake', 'attr_defesatotal']],
          ['Fortitude', data.saves?.fortitude, 'fortitude', ['attr_fortitudetotal']],
          ['Reflexos', data.saves?.reflex, 'reflexos', ['attr_reflexostotal']],
          ['Vontade', data.saves?.will, 'vontade', ['attr_vontadetotal']],
          ...listedSkills.map((skill) => [skill.label, skill.desired, skill.stem, [`attr_${skill.stem}total`]])
        ];
        const pending = [];
        for (const [label, desired, stem, names] of totals) {
          const item = await adjustCalculated(scope, label, desired, `attr_${stem}outros`, names, report);
          if (item) pending.push(item);
        }
        await addEntries(scope, T20_THREAT.repeaters.inventory, data.inventory || [], gifs, report);
        for (const attack of data.attacks || []) await addPlayerAttack(scope, attack, gifs, report);
        for (const feature of data.features || []) await addSourceEntry(scope, T20_THREAT.repeaters.features,
          `${feature.name}${feature.action ? ` (${feature.action})` : ''}`,
          { attr_abilitydescription: feature.description }, gifs, report);
        for (const spell of data.spells || []) {
          const group = groupFor(T20_THREAT.repeaters.spells, spell);
          if (!group) { report.warnings.push(`${spell.name}: círculo não informado; magia ignorada.`); report.skipped++; continue; }
          await addSourceEntry(scope, { ...T20_THREAT.repeaters.spells, group }, spell.name,
            { attr_spelldescription: spell.description || '' }, gifs, report);
        }
        await verifyCalculated(scope, pending, report);
        for (const [attr, desired] of playerExpected) {
          const actual = field(scope, attr)?.value;
          if (actual !== desired) report.warnings.push(`${attr}: esperado ${desired}, valor lido ${actual ?? 'indisponível'}; confira na Ficha Jogador.`);
        }
      } finally {
        // Mesmo com falha parcial, devolva ao usuário a aba em que iniciou.
        if (!await showTab(scope, 'Ficha Ameaça', 'attr_menace_name'))
          report.warnings.push('Não foi possível retornar à Ficha Ameaça. Abra essa aba e confira os dados.');
      }
    }
    if (!visible(field(scope, 'attr_menace_name'))) return;
    await threatWrite('attr_menace_type_size', data.fields?.tipo_tamanho);
    await threatWrite('attr_menace_desloc', data.fields?.deslocamento);
    await threatWrite('attr_menace_treasures', data.fields?.tesouro);
    if (playerReady && data.name) {
      let synced = false;
      for (let i = 0; i < 30; i++) {
        if (field(scope, 'attr_menace_name')?.value === data.name) { synced = true; break; }
        await pause(100);
      }
      if (!synced) {
        write(scope, 'attr_menace_name', data.name, report);
        report.warnings.push('O nome da Ameaça não sincronizou automaticamente com o nome da Ficha Jogador; confira após reabrir a ficha.');
      }
    }
    if (playerReady) {
      for (const attack of data.attacks || []) {
        const name = `${attack.name}${attack.count > 1 ? ` x${attack.count}` : ''}`;
        const group = attack.mode === 'ranged' ? 'repeating_menacedistance' : 'repeating_menacemelee';
        if (!await waitForProjection(scope, group, 'attr_nomeataque', name))
          report.warnings.push(`${name}: ataque salvo na Ficha Jogador, mas a linha da Ameaça ainda não apareceu. Reabra a ficha para conferir.`);
      }
    }
    for (const [attr, desired] of threatExpected) {
      const actual = field(scope, attr)?.value;
      if (actual !== desired) report.warnings.push(`${attr}: esperado ${desired}, valor lido ${actual ?? 'indisponível'}; confira na ficha.`);
    }
  }
  async function apply(doc, data, customProfile, gifs = {}) {
    const scope = scopeOf(doc);
    if (!scope) throw new Error('Ficha aberta não encontrada.');
    const detected = detect(scope);
    if (data.format === 't20-threat' && detected?.id !== 't20-threat' && !customProfile) throw new Error('Bloco de ameaça: abra a aba Ficha Ameaça do Tormenta20 antes de importar; nenhum campo foi alterado.');
    if (detected?.id === 't20-threat' && data.format !== 't20-threat' && !customProfile) throw new Error('A aba Ficha Ameaça está aberta, mas o texto não foi reconhecido como bloco de ameaça; nenhum campo foi alterado.');
    const profile = validateProfile(customProfile || detected);
    if (!profile) throw new Error('Ficha sem perfil. Configure o mapeamento JSON.');
    const report = { profile: profile.label || profile.id || 'Personalizado', changed: 0, added: 0, reused: 0, existing: 0, skipped: 0, warnings: [] };
    if (profile.id === 't20-threat' && !customProfile) {
      await applyThreat(scope, data, gifs, report);
      return report;
    }
    for (const [key, attr] of Object.entries(profile.fields || {})) if (data[key] !== undefined && data[key] !== null) {
      const target = field(scope, attr);
      if (!target) report.warnings.push(`${attr} não encontrado ou editável.`);
      else if (setValue(target, data[key])) report.changed++;
      await pause(80);
    }
    for (const [key, attr] of Object.entries(profile.abilities || {})) if (data.abilities?.[key] !== undefined) {
      const target = field(scope, attr);
      if (!target) report.warnings.push(`${attr} não encontrado ou editável.`);
      else if (setValue(target, profile.id === 't20' && profile.variant === 'Jogo do Ano' && data.abilityModifiers?.[key] !== undefined ? data.abilityModifiers[key] : data.abilities[key])) report.changed++;
      await pause(80);
    }
    for (const [key, value] of Object.entries(data.fields || {})) {
      const attr = profile.extraFields?.[key];
      if (attr && safeAttr(attr) && setValue(field(scope, attr), value)) report.changed++;
    }
    const entries = { inventory: data.inventory || [], attacks: data.attacks || [], spells: data.spells || [] };
    if (['t20', 'dnd5e2014'].includes(profile.id)) {
      const known = new Set(entries.attacks.map((item) => normalize(item.name)));
      const weapon = /\b(?:espada|adaga|arco|machado|lança|lanca|martelo|rapieira|cajado|sword|dagger|bow|axe)\b/i;
      for (const item of entries.inventory) if (weapon.test(item.name) && !known.has(normalize(item.name))) {
        entries.attacks = [...entries.attacks, { name: item.name, count: 1 }];
        known.add(normalize(item.name));
      }
    }
    for (const section of ['inventory', 'attacks', 'spells']) await addEntries(scope, profile.repeaters?.[section], entries[section], gifs, report);
    return report;
  }
  return { T20, T20_THREAT, DND, detect, probe, apply, validateProfile, setValue, imageMarkdown };
});
