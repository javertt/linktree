/* global chrome */
const isRoll20 = (url) => /^https:\/\/app\.roll20\.net\//.test(url || '');

async function targetTab(sender) {
  if (sender.frameId === 0 && sender.tab?.id && isRoll20(sender.tab.url || sender.url)) return sender.tab;
  if (sender.id === chrome.runtime.id && sender.url === chrome.runtime.getURL('popup.html')) {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab?.id && isRoll20(tab.url)) return tab;
  }
  throw new Error('Abra uma mesa em app.roll20.net e depois uma ficha editável.');
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!['PD_DISCOVER', 'PD_IMPORT', 'PD_OPEN_PANEL', 'PD_INSPECT'].includes(message?.type)) return;
  (async () => {
    const tab = await targetTab(sender);
    if (message.type === 'PD_OPEN_PANEL') {
      return await chrome.tabs.sendMessage(tab.id, { type: 'PD_OPEN_PANEL', draft: message.draft || '' }, { frameId: 0 });
    }
    if (message.type === 'PD_DISCOVER') {
      const frames = await chrome.webNavigation.getAllFrames({ tabId: tab.id }) || [];
      const results = await Promise.all(frames.map(async (frame) => {
        try {
          const info = await chrome.tabs.sendMessage(tab.id, { type: 'PD_PROBE' }, { frameId: frame.frameId });
          return { frameId: frame.frameId, url: frame.url, ...info };
        } catch (error) { return { frameId: frame.frameId, url: frame.url, supported: false, reason: 'O script da extensão não respondeu neste quadro.', detail: error.message }; }
      }));
      const diagnostics = results.map((entry) => ({ frameId: entry.frameId, url: entry.url,
        supported: !!entry.supported, reason: entry.reason || entry.error || '',
        sheetCount: entry.sheetCount ?? null, visibleSheetCount: entry.visibleSheetCount ?? null,
        detail: entry.detail || '' }));
      return {
        frames: results.filter((entry) => entry?.supported),
        diagnostics,
        warnings: results.length === 0 || results.every((entry) => entry.reason === 'O script da extensão não respondeu neste quadro.')
          ? ['A extensão não respondeu nesta aba. Atualize a página do Roll20.']
          : results.filter((entry) => entry?.error).map((entry) => entry.error)
      };
    }
    if (!Number.isInteger(message.frameId)) throw new Error('Quadro da ficha inválido.');
    if (message.type === 'PD_INSPECT')
      return await chrome.tabs.sendMessage(tab.id, { type: 'PD_INSPECT' }, { frameId: message.frameId });
    if (!message.data) throw new Error('Importação inválida.');
    return await chrome.tabs.sendMessage(tab.id,
      { type: 'PD_APPLY', data: message.data, gifs: message.gifs || {}, customProfile: message.customProfile || null },
      { frameId: message.frameId });
  })().then(sendResponse).catch((error) => sendResponse({ error: error.message }));
  return true;
});
