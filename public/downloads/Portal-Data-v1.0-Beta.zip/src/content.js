/* global chrome, PortalParser, PortalMacros, PortalRoll20 */
(function () {
  'use strict';
  const isTop = window.top === window;
  const isPopup = document.body?.dataset.portalPopup === 'true';
  let panel;
  let launcher;
  let parsed;
  let discovered = [];
  const call = (payload) => chrome.runtime.sendMessage(payload);
  const $ = (selector) => panel.querySelector(selector);
  const setStatus = (message) => { $('#pd-status').textContent = message; };
  const updateImportButton = () => { $('#pd-import').disabled = !parsed || !discovered.length; };
  const logoSvg = '<svg viewBox="0 0 128 128" aria-hidden="true"><circle cx="64" cy="64" r="61" fill="#111126"/><circle cx="64" cy="64" r="56" fill="#ee956e"/><circle cx="64" cy="64" r="50" fill="#914682"/><circle cx="64" cy="64" r="44" fill="#171631"/><circle cx="64" cy="64" r="39" fill="#362657"/><path d="M63 25 C88 23 103 40 102 62 C102 85 83 101 61 101 C38 101 26 84 28 65 C30 47 46 35 63 38 C81 40 90 54 85 69 C81 83 67 89 55 82 C44 76 44 62 54 55 C63 48 75 53 75 63 C75 71 68 74 63 69" fill="none" stroke="#10162e" stroke-width="17" stroke-linecap="round" stroke-linejoin="round"/><path d="M63 25 C88 23 103 40 102 62 C102 85 83 101 61 101 C38 101 26 84 28 65 C30 47 46 35 63 38 C81 40 90 54 85 69 C81 83 67 89 55 82 C44 76 44 62 54 55 C63 48 75 53 75 63 C75 71 68 74 63 69" fill="none" stroke="#6be1d2" stroke-width="10" stroke-linecap="round" stroke-linejoin="round"/><circle cx="63" cy="67" r="8" fill="#111126"/><circle cx="63" cy="67" r="3" fill="#f7c789"/></svg>';

  function suggest(info) {
    const names = new Set(info.fields);
    const groups = new Set(info.groups);
    const pick = (...options) => options.find((option) => names.has(option));
    const group = (...options) => options.find((option) => groups.has(option));
    const rowField = (groupName, ...options) => options.find((option) => (info.groupFields?.[groupName] || []).includes(option));
    const fields = {
      name: pick('attr_character_name', 'attr_name', 'attr_nome'),
      hp: pick('attr_hp', 'attr_vida', 'attr_pv'),
      hpMax: pick('attr_hp_max', 'attr_vidatotal', 'attr_pv_max'),
      mp: pick('attr_mana', 'attr_pm', 'attr_mp'),
      mpMax: pick('attr_manatotal', 'attr_pm_max', 'attr_mp_max')
    };
    const abilities = {
      strength: pick('attr_strength', 'attr_for', 'attr_forca'), dexterity: pick('attr_dexterity', 'attr_des', 'attr_destreza'),
      constitution: pick('attr_constitution', 'attr_con', 'attr_constituicao'), intelligence: pick('attr_intelligence', 'attr_int', 'attr_inteligencia'),
      wisdom: pick('attr_wisdom', 'attr_sab', 'attr_sabedoria'), charisma: pick('attr_charisma', 'attr_car', 'attr_carisma')
    };
    const repeaters = {};
    const inventory = group('repeating_inventory', 'repeating_equipment', 'repeating_item', 'repeating_itens');
    const attacks = group('repeating_attack', 'repeating_attacks', 'repeating_ataques');
    const spells = group('repeating_spells', 'repeating_magias', 'repeating_magic');
    if (inventory) repeaters.inventory = { group: inventory, name: rowField(inventory, 'attr_itemname', 'attr_equipname', 'attr_nome', 'attr_name') || 'attr_name', count: rowField(inventory, 'attr_itemcount', 'attr_equipquantity', 'attr_quantidade', 'attr_count') || 'attr_count' };
    if (attacks) repeaters.attacks = { group: attacks, name: rowField(attacks, 'attr_atkname', 'attr_nomeataque', 'attr_nome', 'attr_name') || 'attr_name', description: rowField(attacks, 'attr_atk_desc', 'attr_ataquedescricao', 'attr_descricao', 'attr_description') || 'attr_description' };
    if (spells) repeaters.spells = { group: spells, name: rowField(spells, 'attr_spellname', 'attr_namespell', 'attr_nome', 'attr_name') || 'attr_name', description: rowField(spells, 'attr_spelldescription', 'attr_descricao', 'attr_description') || 'attr_description' };
    return { id: 'custom', label: 'Perfil personalizado', fields: Object.fromEntries(Object.entries(fields).filter(([, value]) => value)), abilities: Object.fromEntries(Object.entries(abilities).filter(([, value]) => value)), repeaters, extraFields: {} };
  }

  function renderGifRows() {
    const host = $('#pd-gifs');
    host.replaceChildren();
    const entries = [...parsed.attacks, ...parsed.spells,
      ...(parsed.features || []).map((feature) => ({ name: `${feature.name}${feature.action ? ` (${feature.action})` : ''}` })),
      ...parsed.inventory.filter((item) => /espada|adaga|arco|machado|lança|lanca|martelo|sword|dagger|bow|axe/i.test(item.name))];
    const unique = [...new Map(entries.map((entry) => [entry.name.toLocaleLowerCase('pt-BR'), entry])).values()];
    for (const entry of unique) {
      const name = entry.name;
      const row = document.createElement('div'); row.className = 'pd-gif-row'; row.dataset.name = name;
      const label = document.createElement('label'); label.textContent = name;
      const input = document.createElement('input'); input.type = 'url'; input.placeholder = 'https://.../golpe.gif'; input.className = 'pd-gif-url';
      const dice = document.createElement('input'); dice.type = 'text'; dice.placeholder = '1d6+2'; dice.className = 'pd-dice'; dice.value = entry.damage || '';
      dice.setAttribute('aria-label', `Dano de ${name}`);
      const bonus = document.createElement('input'); bonus.type = 'number'; bonus.placeholder = 'Bônus'; bonus.className = 'pd-bonus';
      bonus.value = Number.isFinite(entry.bonus) ? String(entry.bonus) : '';
      bonus.setAttribute('aria-label', `Bônus de ataque de ${name}`);
      const button = document.createElement('button'); button.type = 'button'; button.textContent = 'Copiar macro';
      button.addEventListener('click', async () => {
        try {
          const macro = PortalMacros.create({ name, gifUrl: input.value, dice: dice.value, attackBonus: bonus.value });
          await navigator.clipboard.writeText(macro.body);
          setStatus(`Macro ${macro.name} copiada. Crie uma macro no Roll20 e cole o conteúdo.`);
        } catch (error) { setStatus(error.message); }
      });
      row.append(label, input, bonus, dice, button); host.append(row);
    }
  }

  function renderSummary(data) {
    const lines = [];
    const list = (label, entries) => {
      if (!entries?.length) return;
      const names = entries.slice(0, 3).map((entry) => entry.name).join(', ');
      lines.push(`${label}: ${entries.length} — ${names}${entries.length > 3 ? '…' : ''}`);
    };
    if (data.name) lines.push(`Nome: ${data.name}`);
    if (data.hp !== null && data.hp !== undefined) lines.push(`Pontos de vida: ${data.hp}${data.hpMax !== null && data.hpMax !== undefined && data.hpMax !== data.hp ? ` / ${data.hpMax}` : ''}`);
    if (data.mp !== null && data.mp !== undefined) lines.push(`Pontos de mana: ${data.mp}${data.mpMax !== null && data.mpMax !== undefined && data.mpMax !== data.mp ? ` / ${data.mpMax}` : ''}`);
    if (data.defense !== null && data.defense !== undefined) lines.push(`Defesa: ${data.defense}`);
    const abilityNames = { strength: 'For', dexterity: 'Des', constitution: 'Con', intelligence: 'Int', wisdom: 'Sab', charisma: 'Car' };
    const abilities = Object.entries(data.abilities || {}).map(([key, value]) => `${abilityNames[key] || key} ${value}`);
    if (abilities.length) lines.push(`Atributos: ${abilities.join(', ')}`);
    list('Ataques', data.attacks);
    list('Equipamentos', data.inventory);
    list('Magias', data.spells);
    list('Habilidades', data.features);
    return lines.join('\n') || 'Nenhum dado reconhecido. Confira o texto antes de importar.';
  }

  async function discover() {
    const button = $('#pd-discover');
    button.disabled = true;
    button.textContent = 'Buscando...';
    $('#pd-copy-inspect').disabled = true;
    setStatus('Buscando a ficha aberta no Roll20...');
    let timer;
    try {
      const response = await Promise.race([
        call({ type: 'PD_DISCOVER' }),
        new Promise((_, reject) => { timer = setTimeout(() => reject(new Error('A busca demorou mais de 10 segundos. Atualize a aba do Roll20 e tente novamente.')), 10000); })
      ]);
      if (response?.error) throw new Error(response.error);
      discovered = response?.frames || [];
      const selector = $('#pd-frame'); selector.replaceChildren();
      discovered.forEach((frame) => {
        const option = document.createElement('option'); option.value = String(frame.frameId);
        const name = frame.name && !frame.name.includes('@{') ? frame.name : 'Ficha aberta';
        option.textContent = `${name} — ${frame.profile === 't20-threat' ? 'Tormenta20 Ameaça' : frame.profile === 't20' ? 'Tormenta20' : frame.profile === 'dnd5e2014' ? 'D&D 5e' : 'Outro sistema'}`;
        selector.append(option);
      });
      updateImportButton();
      if (discovered.length) { selector.value = String(discovered[0].frameId); onFrameChange(); }
      else {
        $('#pd-detected').textContent = '';
        $('#pd-inspect').textContent = JSON.stringify({ diagnostics: response?.diagnostics || [], warnings: response?.warnings || [] }, null, 2);
      }
      $('#pd-copy-inspect').disabled = false;
      const warning = response?.warnings?.length ? ` ${response.warnings.join(' ')}` : '';
      const checked = response?.diagnostics?.length || 0;
      setStatus((discovered.length ? parsed ? 'Ficha encontrada. Confira o resumo e clique em Importar.' : 'Ficha encontrada. Cole o texto e clique em Analisar.' : `Nenhuma ficha editável encontrada em ${checked} quadro(s). Abra a ficha no Roll20 e clique em Atualizar.`) + warning);
    } finally {
      clearTimeout(timer);
      button.disabled = false;
      button.textContent = 'Atualizar';
    }
  }
  function onFrameChange() {
    const info = discovered.find((frame) => frame.frameId === Number($('#pd-frame').value));
    if (!info) return;
    $('#pd-detected').textContent = info.profile === 'generic' ? 'Ficha de outro sistema. Confira o mapeamento em Mais opções.' : '';
    $('#pd-inspect').textContent = '';
    $('#pd-profile').value = info.profile === 'generic' ? JSON.stringify(suggest(info), null, 2) : '';
  }
  function collectGifs() {
    const gifs = {};
    for (const row of panel.querySelectorAll('.pd-gif-row')) {
      const value = row.querySelector('.pd-gif-url').value.trim();
      if (!value) continue;
      const safe = PortalMacros.safeUrl(value);
      if (!safe) throw new Error(`${row.dataset.name}: use URL HTTPS direta para .gif.`);
      gifs[row.dataset.name] = safe;
    }
    return gifs;
  }
  function createPanel() {
    if (panel) return;
    parsed = null;
    panel = document.createElement('section'); panel.id = 'portal-data-panel';
    panel.innerHTML = `<header><strong class="pd-brand">${logoSvg}Portal Data</strong><button type="button" id="pd-close" aria-label="Fechar">×</button></header>
      <p id="pd-status" role="status" aria-live="polite">Cole o texto da ficha para começar.</p>
      <label for="pd-text">Texto da ficha</label><textarea id="pd-text" placeholder="Cole aqui a ficha ou o bloco de ameaça"></textarea>
      <button type="button" id="pd-parse">Analisar texto</button>
      <div id="pd-summary" aria-live="polite"></div>
      <div class="pd-destination"><label for="pd-frame">Importar para</label><div class="pd-destination-row"><select id="pd-frame" aria-label="Ficha de destino"></select><button type="button" id="pd-discover" title="Procurar ficha novamente">Atualizar</button></div><small id="pd-detected"></small></div>
      <button type="button" id="pd-import" disabled>Importar na ficha</button>
      <details id="pd-options"><summary>Mais opções</summary>
        <details id="pd-gif-options"><summary>Macros de ataque e GIFs (opcional)</summary><p>As armas importadas usam o botão de rolagem da ficha. Para criar um atalho separado, copie a macro abaixo. O GIF é opcional.</p><div id="pd-gifs"></div></details>
        <details id="pd-analysis-details"><summary>Detalhes da análise</summary><pre id="pd-raw"></pre></details>
        <details><summary>Relatório da importação</summary><pre id="pd-report"></pre></details>
        <details><summary>Configuração para outras fichas</summary><p>Use apenas se a ficha não for reconhecida automaticamente.</p><textarea id="pd-profile" aria-label="Mapeamento personalizado JSON" spellcheck="false"></textarea></details>
        <details><summary>Diagnóstico para suporte</summary><button type="button" id="pd-copy-inspect" disabled>Copiar diagnóstico</button><pre id="pd-inspect"></pre></details>
      </details>`;
    (isPopup ? document.body : document.documentElement).append(panel);
    $('#pd-close').addEventListener('click', () => { panel.remove(); panel = null; });
    const showDiscoverError = (error) => {
      $('#pd-inspect').textContent = JSON.stringify({ error: error.message }, null, 2);
      $('#pd-copy-inspect').disabled = false;
      setStatus(error.message);
    };
    $('#pd-copy-inspect').addEventListener('click', async () => {
      try {
        const frameId = Number($('#pd-frame').value);
        if (discovered.some((entry) => entry.frameId === frameId)) {
          const info = await call({ type: 'PD_INSPECT', frameId });
          if (info?.error) throw new Error(info.error);
          if (!info?.supported) throw new Error('A ficha não está mais aberta. Clique em Atualizar.');
          $('#pd-inspect').textContent = JSON.stringify({ fields: info.fields, groupFields: info.groupFields, groupControls: info.groupControls || {}, groupLayout: info.groupLayout || {}, tabs: info.tabs || [], controls: info.controls || [], coreControls: info.coreControls || [] }, null, 2);
        }
        await navigator.clipboard.writeText($('#pd-inspect').textContent);
        setStatus('Diagnóstico copiado. Ele não inclui os valores da ficha.');
      }
      catch (error) { setStatus(`Não foi possível copiar: ${error.message}`); }
    });
    if (isPopup) {
      const openPage = document.createElement('button');
      openPage.type = 'button';
      openPage.id = 'pd-open-page';
      openPage.textContent = 'Abrir painel no Roll20';
      $('#pd-options').append(openPage);
      openPage.addEventListener('click', async () => {
        try {
          const result = await call({ type: 'PD_OPEN_PANEL', draft: $('#pd-text').value });
          if (result.error) throw new Error(result.error);
          window.close();
        } catch (error) { setStatus(`Não foi possível abrir na página. ${error.message} Recarregue o Roll20 e tente novamente.`); }
      });
    }
    $('#pd-text').addEventListener('input', () => {
      parsed = null;
      $('#pd-summary').textContent = '';
      $('#pd-raw').textContent = '';
      $('#pd-report').textContent = '';
      $('#pd-gifs').replaceChildren();
      updateImportButton();
      setStatus('Texto alterado. Clique em Analisar texto para continuar.');
    });
    $('#pd-gif-options').addEventListener('toggle', () => {
      if ($('#pd-gif-options').open && parsed && !$('#pd-gifs').children.length) renderGifRows();
    });
    $('#pd-analysis-details').addEventListener('toggle', () => {
      if ($('#pd-analysis-details').open && parsed) $('#pd-raw').textContent = JSON.stringify(parsed, null, 2);
    });
    $('#pd-parse').addEventListener('click', () => {
      try {
        parsed = PortalParser.parse($('#pd-text').value);
        $('#pd-summary').textContent = renderSummary(parsed);
        $('#pd-raw').textContent = $('#pd-analysis-details').open ? JSON.stringify(parsed, null, 2) : '';
        if ($('#pd-gif-options').open) renderGifRows();
        else $('#pd-gifs').replaceChildren();
        updateImportButton();
        setStatus(parsed.format === 't20-threat'
          ? 'Ameaça analisada. Confira o resumo e a ficha de destino.'
          : 'Texto analisado. Confira o resumo e a ficha de destino.');
      } catch (error) { setStatus(error.message); }
    });
    $('#pd-discover').addEventListener('click', () => discover().catch(showDiscoverError));
    $('#pd-frame').addEventListener('change', onFrameChange);
    $('#pd-import').addEventListener('click', async () => {
      if (!parsed) { setStatus('Analise o texto primeiro.'); return; }
      try {
        const frameId = Number($('#pd-frame').value);
        const info = discovered.find((entry) => entry.frameId === frameId);
        if (!info) throw new Error('Selecione uma ficha válida.');
        const profileText = $('#pd-profile').value.trim();
        const customProfile = profileText ? PortalRoll20.validateProfile(JSON.parse(profileText)) : null;
        const gifs = collectGifs();
        $('#pd-import').disabled = true; setStatus('Importando campos e linhas...');
        const result = await call({ type: 'PD_IMPORT', frameId, data: parsed, customProfile, gifs });
        if (result.error) throw new Error(result.error);
        const partial = result.skipped || result.warnings?.length;
        $('#pd-report').textContent = `${result.changed} campos alterados; ${result.added} linhas criadas; ${result.reused || 0} linhas vazias aproveitadas; ${result.existing} já existentes; ${result.skipped} ignoradas.\n${(result.warnings || []).join('\n')}`;
        setStatus(partial ? 'Importação parcial. Confira os detalhes em Mais opções e revise a ficha.' : 'Importação concluída. Confira a ficha no Roll20.');
      } catch (error) { setStatus(error.message); }
      finally { updateImportButton(); }
    });
    discover().catch(showDiscoverError);
  }
  function createLauncher() {
    if (launcher || !isTop || isPopup) return;
    launcher = document.createElement('button');
    launcher.id = 'portal-data-launcher';
    launcher.type = 'button';
    launcher.setAttribute('aria-label', 'Abrir Portal Data');
    launcher.innerHTML = `${logoSvg}<span aria-hidden="true">Portal Data</span>`;
    launcher.addEventListener('click', () => { if (panel) { panel.remove(); panel = null; } else createPanel(); });
    document.documentElement.append(launcher);
  }
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === 'PD_TOGGLE' && isTop) { if (panel) { panel.remove(); panel = null; } else createPanel(); return; }
    if (message?.type === 'PD_OPEN_PANEL' && isTop && !isPopup) {
      createPanel();
      if (message.draft) $('#pd-text').value = message.draft;
      sendResponse({ ok: true });
      return;
    }
    if (message?.type === 'PD_PROBE') { sendResponse(PortalRoll20.probe(document, false)); return; }
    if (message?.type === 'PD_INSPECT') { sendResponse(PortalRoll20.probe(document)); return; }
    if (message?.type === 'PD_APPLY') {
      PortalRoll20.apply(document, message.data, message.customProfile, message.gifs)
        .then(sendResponse).catch((error) => sendResponse({ error: error.message }));
      return true;
    }
  });
  if (isPopup) createPanel();
  else if (isTop) {
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', createLauncher, { once: true });
    else createLauncher();
  }
})();
