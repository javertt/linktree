(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  root.PortalParser = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const abilities = {
    strength: /^(?:força|forca|strength|str|for)\b/i,
    dexterity: /^(?:destreza|dexterity|dex|des)\b/i,
    constitution: /^(?:constituição|constituicao|constitution|con)\b/i,
    intelligence: /^(?:inteligência|inteligencia|intelligence|int)\b/i,
    wisdom: /^(?:sabedoria|wisdom|wis|sab)\b/i,
    charisma: /^(?:carisma|charisma|cha|car)\b/i
  };
  const clean = (value) => value.replace(/\*\*/g, '').replace(/^[-*•]\s*/, '').trim();
  const key = (value) => value.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
  const number = (value) => Number(value.replace(/[−–—]/g, '-'));

  function emptyResult() {
    return { name: '', abilities: {}, abilityModifiers: {}, hp: null, hpMax: null, mp: null, mpMax: null, fields: {}, inventory: [], attacks: [], spells: [], warnings: [] };
  }

  function parseListEntry(line) {
    const source = clean(line);
    const qty = source.match(/^(\d+)\s*[x×]\s*(.+)$/i) || source.match(/^(.+?)\s*[x×]\s*(\d+)$/i);
    if (qty) return /^\d/.test(qty[1]) ? { name: qty[2].trim(), count: Number(qty[1]) } : { name: qty[1].trim(), count: Number(qty[2]) };
    return { name: source, count: 1 };
  }

  function parseThreat(text) {
    const result = { ...emptyResult(), format: 't20-threat', creature: {}, saves: {}, movement: {}, skills: [], features: [] };
    const lines = text.split(/\r?\n/).map((raw) => clean(raw.replace(/^#{1,6}\s*/, ''))).filter(Boolean);
    // Um recorte do bestiário pode começar pela classificação da criatura,
    // sem a linha do nome. Nesse caso preservamos o nome já presente na ficha.
    const creatureHeading = /^(?:Humanoide|Animal|Monstro|Construto|Morto[ -]vivo|Espírito|Aberração|Elemental|Dragão|Planta|Limo|Inseto)(?:\s+\([^)]+\))?\s+(?:Minúsculo|Pequeno|Médio|Grande|Enorme|Colossal)$/i;
    if (lines.length && !/^(?:nome|name)\s*:/i.test(lines[0]) && !creatureHeading.test(lines[0])) result.name = lines.shift();
    let activeFeature = null;
    for (const line of lines) {
      const normalized = line.replace(/[−–—]/g, '-');
      let match;
      if ((match = line.match(/^(?:nome|name)\s*[:：]\s*(.+)$/i))) { result.name = match[1].trim(); activeFeature = null; continue; }
      if ((match = line.match(/^(.+?)(?:\s+\(([^)]+)\))?\s+(Minúsculo|Pequeno|Médio|Grande|Enorme|Colossal)$/i)) && !result.creature.size) {
        result.creature = { type: match[1].trim(), subtype: match[2] || '', size: match[3] };
        result.fields.tipo_criatura = result.creature.type + (result.creature.subtype ? ` (${result.creature.subtype})` : '');
        result.fields.tamanho = result.creature.size;
        result.fields.tipo_tamanho = `${result.fields.tipo_criatura} ${result.creature.size}`;
        activeFeature = null; continue;
      }
      if (/^Iniciativa\b/i.test(line)) {
        const initiative = normalized.match(/\bIniciativa\s*([+-]?\d+)/i);
        const perception = normalized.match(/\bPercepção\s*([+-]?\d+)/i);
        if (initiative) { result.initiative = number(initiative[1]); result.fields.iniciativa = String(result.initiative); }
        if (perception) { result.perception = number(perception[1]); result.fields.percepcao = String(result.perception); }
        activeFeature = null; continue;
      }
      if (/^Defesa\b/i.test(line)) {
        const labels = { defesa: 'defense', fort: 'fortitude', ref: 'reflex', von: 'will' };
        for (const part of normalized.split(/\s*,\s*/)) {
          const stat = part.match(/^(Defesa|Fort|Ref|Von)\s*([+-]?\d+)$/i);
          if (!stat) continue;
          const label = key(stat[1]);
          const value = number(stat[2]);
          result.fields[label] = String(value);
          if (label === 'defesa') result.defense = value;
          else result.saves[labels[label]] = value;
        }
        activeFeature = null; continue;
      }
      if ((match = normalized.match(/^(?:Pontos de Vida|PV|HP)\s*[:：]?\s*(\d+)(?:\s*\/\s*(\d+))?\.?$/i))) {
        result.hp = Number(match[1]); result.hpMax = Number(match[2] || match[1]); activeFeature = null; continue;
      }
      if ((match = normalized.match(/^(?:Pontos de Mana|PM|MP)\s*[:：]?\s*(\d+)(?:\s*\/\s*(\d+))?\.?$/i))) {
        result.mp = Number(match[1]); result.mpMax = Number(match[2] || match[1]); activeFeature = null; continue;
      }
      if ((match = line.match(/^Deslocamento\s*[:：]?\s*(\d+)\s*m(?:\s*\((\d+)\s*q\))?\.?$/i))) {
        result.movement = { meters: Number(match[1]), squares: match[2] ? Number(match[2]) : null };
        result.fields.deslocamento = `${result.movement.meters}m${result.movement.squares === null ? '' : ` (${result.movement.squares}q)`}`;
        activeFeature = null; continue;
      }
      if ((match = normalized.match(/^(Corpo a Corpo|À Distância|A Distância)\s+(.+?)\s+(?:x(\d+)\s+)?([+-]\d+)\s*\(([^)]+)\)\.?$/i))) {
        const [damage, critical] = match[5].split(/\s*,\s*/);
        const attack = { name: match[2].trim(), count: Number(match[3] || 1), mode: /^Corpo/i.test(match[1]) ? 'melee' : 'ranged', bonus: number(match[4]), damage: damage.trim() };
        if (/^\d{2}$/.test(critical || '')) attack.critical = Number(critical);
        result.attacks.push(attack);
        activeFeature = null; continue;
      }
      if (/^For\s*[+\-−–—]?\d+\s*,/i.test(line)) {
        const short = { for: 'strength', des: 'dexterity', con: 'constitution', int: 'intelligence', sab: 'wisdom', car: 'charisma' };
        for (const part of normalized.split(/\s*,\s*/)) {
          const ability = part.match(/^(For|Des|Con|Int|Sab|Car)\s*([+-]?\d+)$/i);
          if (ability) result.abilities[short[key(ability[1])]] = number(ability[2]);
        }
        activeFeature = null; continue;
      }
      if ((match = normalized.match(/^Perícias\s+(.+)\.?$/i))) {
        for (const part of match[1].replace(/\.$/, '').split(/\s*,\s*/)) {
          const skill = part.match(/^(.+?)\s+([+-]?\d+)$/);
          if (skill) result.skills.push({ name: skill[1].trim(), bonus: number(skill[2]) });
        }
        result.fields.pericias = result.skills.map((skill) => `${skill.name} ${skill.bonus >= 0 ? '+' : ''}${skill.bonus}`).join(', ');
        activeFeature = null; continue;
      }
      if ((match = line.replace(/\.$/, '').match(/^Equipamento\s+(.+?)(?:\s+Tesouro\s+(.+))?$/i))) {
        result.inventory.push(...match[1].split(/\s*,\s*/).map(parseListEntry));
        if (match[2]) result.fields.tesouro = match[2].trim();
        activeFeature = null; continue;
      }
      if ((match = line.match(/^Tesouro\s+(.+)\.?$/i))) {
        result.fields.tesouro = match[1].replace(/\.$/, '').trim(); activeFeature = null; continue;
      }
      if ((match = line.match(/^(.+?)\s+\((Livre|Padrão|Movimento|Completa|Reação)\)\s+(.+)$/i))) {
        activeFeature = { name: match[1].trim(), action: match[2], description: match[3].trim() };
        result.features.push(activeFeature); continue;
      }
      if ((match = normalized.match(/^(.+?)\s+(\+\d+d\d+)\.?$/i))) {
        result.features.push({ name: match[1].trim(), action: '', description: `${match[2]}.` });
        activeFeature = null; continue;
      }
      if (activeFeature) { activeFeature.description += ` ${line}`; continue; }
      result.warnings.push(`Linha não reconhecida: ${line}`);
    }
    if (result.attacks.length) result.fields.ataques = result.attacks.map((attack) => `${attack.mode === 'melee' ? 'Corpo a Corpo' : 'À Distância'} ${attack.name}${attack.count > 1 ? ` x${attack.count}` : ''} ${attack.bonus >= 0 ? '+' : ''}${attack.bonus} (${attack.damage}).`).join('\n');
    if (result.features.length) result.fields.habilidades = result.features.map((feature) => `${feature.name} (${feature.action}) ${feature.description}`).join('\n');
    if (result.inventory.length) result.fields.equipamentos = result.inventory.map((item) => `${item.name}${item.count > 1 ? ` x${item.count}` : ''}`).join(', ');
    if (!result.name) result.warnings.push('Nome não encontrado.');
    return result;
  }

  function parse(text) {
    if (typeof text !== 'string' || text.length > 100000) throw new Error('Cole uma ficha com até 100.000 caracteres.');
    if (/^\s*(?:Corpo a Corpo|À Distância|A Distância|Defesa\s+\d+\s*,\s*Fort|Pontos de Vida\s+\d+)/im.test(text)) return parseThreat(text);
    const result = emptyResult();
    let section = '';
    let spellLevel = null;
    for (const raw of text.split(/\r?\n/)) {
      const line = clean(raw.replace(/^#{1,6}\s*/, ''));
      if (!line) continue;
      const heading = key(line.replace(/:$/, ''));
      if (/^(inventario|equipamento|itens|inventory|equipment)$/.test(heading)) { section = 'inventory'; continue; }
      if (/^(ataques|armas|attacks|weapons)$/.test(heading)) { section = 'attacks'; continue; }
      if (/^(magias|feiticos|spells|magic)$/.test(heading)) { section = 'spells'; continue; }
      if (section === 'spells') {
        const circleHeading = line.match(/^(?:(\d)\s*[º°o]?\s*(?:círculo|circulo|nível|nivel|level)|(?:círculo|circulo|nível|nivel|level)\s*(\d))\s*:?$/i);
        if (circleHeading) { spellLevel = Number(circleHeading[1] || circleHeading[2]); continue; }
        if (/^(?:truques|cantrips)\s*:?$/i.test(line)) { spellLevel = 0; continue; }
      }
      const name = line.match(/^(?:nome|name|personagem|character)\s*[:：]\s*(.+)$/i);
      if (name) { result.name = name[1].trim(); section = ''; continue; }
      const hp = line.match(/^(?:pv|pontos de vida|vida|hp|hit points?)\s*[:：]\s*(\d+)(?:\s*\/\s*(\d+))?/i);
      if (hp) { result.hp = Number(hp[1]); result.hpMax = Number(hp[2] || hp[1]); section = ''; continue; }
      const mp = line.match(/^(?:pm|pontos de mana|mana|mp)\s*[:：]\s*(\d+)(?:\s*\/\s*(\d+))?/i);
      if (mp) { result.mp = Number(mp[1]); result.mpMax = Number(mp[2] || mp[1]); section = ''; continue; }
      const abilityLine = line.replace(/^[*\s]+/, '');
      let found = false;
      for (const [ability, pattern] of Object.entries(abilities)) {
        const match = abilityLine.match(pattern);
        if (!match) continue;
        const suffix = abilityLine.slice(match[0].length);
        const score = suffix.match(/^\s*(?:[:：=]|\s)\s*([+-]?\d{1,2})(?!\d)/);
        if (score) {
          result.abilities[ability] = Number(score[1]);
          const modifier = suffix.match(/\(([+-]\d{1,2})\)/);
          if (modifier) result.abilityModifiers[ability] = Number(modifier[1]);
          found = true; break;
        }
      }
      if (found) { section = ''; continue; }
      const field = line.match(/^([\p{L}][\p{L}\p{N} _-]{1,40})\s*[:：]\s*(.{1,200})$/u);
      if (field && !(section === 'spells' && /^(?:círculo|circulo|nível|nivel|level)\s*\d$/i.test(field[1]))) {
        const value = field[2].trim();
        result.fields[key(field[1]).replace(/\s+/g, '_')] = /^[+-]?\d+[,]\d+$/.test(value) ? value.replace(',', '.') : value;
        section = ''; continue;
      }
      if (!section || /^(?:nível|nivel|level|classe|class|raça|raca|race)\s*[:：]/i.test(line)) continue;
      if (section === 'inventory') {
        const item = parseListEntry(line);
        if (item.name) result.inventory.push(item);
      } else if (section === 'attacks') {
        const attack = parseListEntry(line);
        if (attack.name) result.attacks.push(attack);
      } else if (section === 'spells') {
        const match = line.match(/^(?:\[?\s*(?:círculo|circulo|nível|nivel|level)\s*(\d|truque|cantrip)\s*\]?\s*[:\-–]?\s*)?(.+)$/i);
        if (match) {
          const level = /truque|cantrip/i.test(match[1] || '') ? 0 : match[1] === undefined ? null : Number(match[1]);
          const tailLevel = match[2].match(/\((?:nível|nivel|level|círculo|circulo)\s*(\d)\)\s*$/i);
          const finalLevel = level === null ? tailLevel ? Number(tailLevel[1]) : spellLevel : level;
          const spellName = match[2].replace(/\s*\((?:nível|nivel|level|círculo|circulo)\s*\d\)\s*$/i, '').trim();
          if (spellName) result.spells.push({ name: spellName, level: finalLevel });
        }
      }
    }
    if (!result.name) result.warnings.push('Nome não encontrado.');
    if (result.spells.some((spell) => spell.level === null)) result.warnings.push('Magias sem círculo/nível precisam de um grupo manual para importação.');
    return result;
  }
  return { parse };
});
